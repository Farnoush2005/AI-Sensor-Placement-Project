"""
University: University of Isfahan
Faculty: Mathematics and Statistics
Branch: Computer Science
Course: Artificial Intelligence
Professor: Dr. Faria Nasiri Mofakham
TAs: MehrAzin Marzough, Mohammad Karimi, Anahita Honarmandian
Project: Implementing Local Search Algorithms for a Sensor Placement Optimization Problem
"""

import re
import matplotlib
matplotlib.use("TkAgg")

from env.grid_world import GridWorld
from search.hill_climbing import HillClimbing
from search.simulated_annealing import SimulatedAnnealing
from search.genetic_algorithm import GeneticAlgorithm
from search.beam_search import BeamSearch
from search.tabu_search import TabuSearch
from utils import represent


def run_algorithms(world, initial_state, algorithm_classes):
    best_states, best_costs, evaluations, histories, names = [], [], [], [], []

    for algo_class in algorithm_classes:
        
        name = re.sub(r'(?<!^)([A-Z])', r' \1', algo_class.__name__)
        names.append(name)

        algo_instance = algo_class(world)
        print(f"Running {name}...")

        
        state, cost, evals, hist = algo_instance.run(initial_state)

        best_states.append(state)
        best_costs.append(cost)
        evaluations.append(evals)
        histories.append(hist)


    represent(best_states, best_costs, evaluations, histories, names, world)


if __name__ == "__main__":
    
    world = GridWorld("map3")

    algorithm_classes = [
        HillClimbing,
        SimulatedAnnealing,
        GeneticAlgorithm,
        BeamSearch,
        TabuSearch
    ]


    base_search = HillClimbing(world)
    initial_state = base_search.initialize_state()

    run_algorithms(world, initial_state, algorithm_classes)