import matplotlib.pyplot as plt
import pygame

from env.renderer import Renderer


def draw_results(values: list, names: list):
    
    plt.figure(figsize=(10, 5))

    for i in range(len(values)):
        plt.plot(values[i], label=names[i])

    plt.title("Local Search Algorithms — Cost over Iterations")
    plt.xlabel("Iteration")
    plt.ylabel("Cost")
    plt.legend()
    plt.tight_layout()
    plt.show()


def print_results(states: list, costs: list, names: list, evals_list: list, histories: list):
   
    for i in range(len(states)):
        print(f"\n{'=' * 50}")
        print(f"  {names[i]}")
        print(f"{'=' * 50}")

        print(f"best_state     : {states[i]}")
        print(f"best_cost      : {costs[i]}")

        evals = evals_list[i]
        
        truncated_evals = evals[:5]
        suffix = '...' if len(evals) > 5 else ''
        print(f"evaluations    : {truncated_evals}{suffix}")
        print(f"  (Total Steps: {len(evals)} | Initial Cost: {evals[0]} | Final Cost: {evals[-1]})")

        hist = histories[i]
        print(f"states_history : {len(hist)} states recorded | Best state sensors: {len(states[i])}")


def render_history(histories: list, evals_list: list, names: list, world):
    
    renderer = Renderer(world)

    for i in range(len(histories)):
        renderer.animate(
            histories[i],
            evals_list[i],
            names[i],
            delay=50
        )

    pygame.quit()


def represent(best_states: list, best_costs: list, evaluations: list, histories: list, names: list, world):
    
    print_results(
        states=best_states,
        costs=best_costs,
        names=names,
        evals_list=evaluations,
        histories=histories
    )

    draw_results(
        values=evaluations,
        names=names
    )

    
    render_history(
        histories=histories,
        evals_list=evaluations,
        names=names,
        world=world
    )