import random
import copy
from search.local_search_base import LocalSearchBase

class GeneticAlgorithm(LocalSearchBase):
    def run(self, initial_state, population_size=40, generations=200,
            mutation_rate=0.3, tournament_size=4, **kwargs):

        # پر کردن جمعیت اولیه با استیت فعلی و بقیه به صورت رندوم
        pop = [copy.deepcopy(initial_state)]
        while len(pop) < population_size:
            pop.append(self.initialize_state())

        best_state = copy.deepcopy(initial_state)
        best_cost = self.evaluate(best_state)

        evaluations = []
        states_history = []

        for _ in range(generations):
            # محاسبه کاست هر عضو و سورت کردن از کم به زیاد
            pop_costs = [(state, self.evaluate(state)) for state in pop]
            pop_costs.sort(key=lambda x: x[1])

            # آپدیت کردن بهترین جواب کلی در صورت پیدا شدن حالت بهتر
            if pop_costs[0][1] < best_cost:
                best_cost = pop_costs[0][1]
                best_state = copy.deepcopy(pop_costs[0][0])

            evaluations.append(best_cost)
            states_history.append(copy.deepcopy(best_state))

            # انتقال دو تا از بهترین‌ها به نسل بعد (Elitism)
            new_pop = [
                copy.deepcopy(pop_costs[0][0]),
                copy.deepcopy(pop_costs[1][0])
            ]

            # تولید بقیه جمعیت نسل جدید با کراس‌اور و میوتیشن
            while len(new_pop) < population_size:
                p1 = self._tournament_selection(pop_costs, tournament_size)
                p2 = self._tournament_selection(pop_costs, tournament_size)

                child = self._crossover(p1, p2)

                if random.random() < mutation_rate:
                    child = self._mutate(child)

                new_pop.append(child)

            pop = new_pop

        return best_state, best_cost, evaluations, states_history

    def _tournament_selection(self, pop_costs, k):
        # انتخاب k عضو تصادفی و برگردوندن اونی که کاستش کمتره
        tournament = random.sample(pop_costs, k)
        tournament.sort(key=lambda x: x[1])
        return copy.deepcopy(tournament[0][0])

    def _crossover(self, p1, p2):
        # ترکیب نصف سنسورهای والد اول و نصف والد دوم
        sp1 = len(p1) // 2
        sp2 = len(p2) // 2

        child = p1[:sp1] + p2[sp2:]
        child = list(set(child))  # حذف سنسورهای تکراری در یک نقطه

        # رعایت محدودیت حداکثر تعداد سنسورها
        if len(child) > self.max_sensors:
            child = random.sample(child, self.max_sensors)

        if len(child) == 0:
            child = self.initialize_state()

        return child

    def _mutate(self, state):
        # اعمال جهش روی فرزند با استفاده از متد همسایگی
        return self.get_neighbor(state)
    

    