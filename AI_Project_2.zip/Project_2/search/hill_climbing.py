import copy
from search.local_search_base import LocalSearchBase

class HillClimbing(LocalSearchBase):
    def run(self, initial_state, max_iterations=1000, sample_size=30, **kwargs):
        curr_state = copy.deepcopy(initial_state)
        curr_cost = self.evaluate(curr_state)

        evaluations = [curr_cost]
        states_history = [copy.deepcopy(curr_state)]

        for _ in range(max_iterations):
            best_nb = None
            best_nb_cost = float('inf')

            # نمونه‌برداری تصادفی از همسایه‌ها برای پیدا کردن بهترینشون
            for _ in range(sample_size):
                nb = self.get_neighbor(curr_state)
                nb_cost = self.evaluate(nb)

                if nb_cost < best_nb_cost:
                    best_nb = nb
                    best_nb_cost = nb_cost

            # اگه همسایه‌ها بهتر نبودن، یعنی تو بهینه محلی گیر کردیم و تمام
            if best_nb_cost >= curr_cost:
                break

            curr_state = best_nb
            curr_cost = best_nb_cost

            evaluations.append(curr_cost)
            states_history.append(copy.deepcopy(curr_state))

        return curr_state, curr_cost, evaluations, states_history
    

    