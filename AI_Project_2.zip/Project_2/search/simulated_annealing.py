import math
import random
import copy
from search.local_search_base import LocalSearchBase

class SimulatedAnnealing(LocalSearchBase):
    def run(self, initial_state, initial_temp=1000.0, cooling_rate=0.99, min_temp=0.1, **kwargs):
        curr_state = copy.deepcopy(initial_state)
        curr_cost = self.evaluate(curr_state)

        best_state = copy.deepcopy(curr_state)
        best_cost = curr_cost

        evaluations = [curr_cost]
        states_history = [copy.deepcopy(curr_state)]

        t = initial_temp

        while t > min_temp:
            nb = self.get_neighbor(curr_state)
            nb_cost = self.evaluate(nb)

            delta = nb_cost - curr_cost

            # اگه همسایه بهتر بود یا شانس آوردیم (بر اساس دما)، قبولش میکنیم
            if delta < 0 or random.random() < math.exp(-delta / t):
                curr_state = nb
                curr_cost = nb_cost

                # آپدیت کردن بهترین جوابی که تا الان دیدیم
                if curr_cost < best_cost:
                    best_state = copy.deepcopy(curr_state)
                    best_cost = curr_cost

            evaluations.append(curr_cost)
            states_history.append(copy.deepcopy(curr_state))

            # سیستم رو سرد میکنیم
            t *= cooling_rate

        return best_state, best_cost, evaluations, states_history
    
    