import copy
import random
from search.local_search_base import LocalSearchBase

class BeamSearch(LocalSearchBase):
    def run(self, initial_state, beam_width=5, max_iterations=100, **kwargs):

        # پر کردن پرتو (بیم) اولیه با استیت فعلی و بقیه به صورت رندوم
        curr_states = [copy.deepcopy(initial_state)]
        while len(curr_states) < beam_width:
            curr_states.append(self.initialize_state())

        best_state = min(curr_states, key=self.evaluate)
        best_cost = self.evaluate(best_state)

        evaluations = [best_cost]
        states_history = [copy.deepcopy(best_state)]

        for _ in range(max_iterations):
            all_nbs = []

            # تولید ۱۲ همسایه برای هر کدوم از وضعیت‌های داخل بیم
            for state in curr_states:
                for _ in range(12):
                    all_nbs.append(self.get_neighbor(state))

            # سورت کردن کل همسایه‌ها بر اساس کاست
            all_nbs.sort(key=self.evaluate)

            # انتخاب بهترین‌ها به تعداد پهنای بیم (beam_width) برای نسل بعد
            curr_states = copy.deepcopy(all_nbs[:beam_width])

            step_best_cost = self.evaluate(curr_states[0])

            #آپدیت کردن بهترین جواب کلی 
            if step_best_cost < best_cost:
                best_cost = step_best_cost
                best_state = copy.deepcopy(curr_states[0])

            evaluations.append(best_cost)
            states_history.append(copy.deepcopy(best_state))

        return best_state, best_cost, evaluations, states_history
    
    