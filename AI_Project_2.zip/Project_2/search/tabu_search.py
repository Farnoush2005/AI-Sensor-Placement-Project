import copy
import random
from search.local_search_base import LocalSearchBase

class TabuSearch(LocalSearchBase):
    def run(self, initial_state, tabu_size=15, max_iterations=120, num_neighbors=25, **kwargs):

        curr_state = copy.deepcopy(initial_state)
        curr_cost = self.evaluate(curr_state)

        best_state = copy.deepcopy(curr_state)
        best_cost = curr_cost

        evaluations = [curr_cost]
        states_history = [copy.deepcopy(best_state)]

        # تبدیل استیت به تیوپل سورت‌شده واسه اینکه بتونیم تو لیست تابو چک کنیم
        to_key = lambda s: tuple(sorted(s))
        tabu_list = [to_key(curr_state)]

        for _ in range(max_iterations):
            candidates = []
            
            # تولید همسایه‌ها و حساب کردن کاست و کلید هر کدوم
            for _ in range(num_neighbors):
                nb = self.get_neighbor(curr_state)
                nb_cost = self.evaluate(nb)
                nb_key = to_key(nb)
                candidates.append((nb, nb_cost, nb_key))

            candidates.sort(key=lambda x: x[1])

         
            chosen = None
            for nb, nb_cost, nb_key in candidates:
                if nb_key not in tabu_list or nb_cost < best_cost:
                    chosen = (nb, nb_cost, nb_key)
                    break

            # اگه همه کاندیداها تابو بودن، مجبوری اولین (بهترین) رو برمیداریم
            if chosen is None and candidates:
                chosen = candidates[0]

            if chosen:
                curr_state, curr_cost, chosen_key = chosen

                # آپدیت بهترین جواب کلی
                if curr_cost < best_cost:
                    best_cost = curr_cost
                    best_state = copy.deepcopy(curr_state)

                # اضافه کردن به لیست تابو و رعایت سقف اندازه لیست
                tabu_list.append(chosen_key)
                if len(tabu_list) > tabu_size:
                    tabu_list.pop(0)

            evaluations.append(best_cost)
            states_history.append(copy.deepcopy(best_state))

        return best_state, best_cost, evaluations, states_history