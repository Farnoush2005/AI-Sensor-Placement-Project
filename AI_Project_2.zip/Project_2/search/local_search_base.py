import copy
import random

class LocalSearchBase:
    def __init__(self, world):
        self.world = world
        self.max_sensors = world.max_sensors
        self.sensor_range = world.sensor_range
        self.targets = self.world.get_targets()

    def evaluate(self, state):
        covered = set()
        
        # بررسی پوشش تارگت‌ها با فاصله منهتن
        for t in self.targets:
            for s in state:
                dist = abs(t[0] - s[0]) + abs(t[1] - s[1])
                if dist <= self.sensor_range:
                    covered.add(t)
                    break
                    
        # فرمول هزینه: هر تارگت جریمه ۱۰۰ و هر سنسور جریمه ۱۰
        uncovered_count = len(self.targets) - len(covered)
        return (uncovered_count * 100) + (len(state) * 10)

    def get_neighbor(self, state):
        # مشخص کردن کارهای مجاز بر اساس محدودیت‌ها
        ops = ['move']
        if len(state) < self.max_sensors:
            ops.append('add')
        if len(state) > 1:
            ops.append('remove')
            
        op = random.choice(ops)
        new_state = copy.deepcopy(state)
        
        if op == 'move':
            idx = random.randint(0, len(new_state) - 1)
            cx, cy = new_state[idx]
            
            # جابه‌جایی در ۴ جهت اصلی به صورت تصادفی
            dirs = [(-1, 0), (1, 0), (0, -1), (0, 1)]
            random.shuffle(dirs)
            moved = False
            
            for dx, dy in dirs:
                nx, ny = cx + dx, cy + dy
                if self.world.is_valid_position(nx, ny) and (nx, ny) not in new_state:
                    new_state[idx] = (nx, ny)
                    moved = True
                    break
                    
            # اگه دورش بسته بود، یه جای تصادفی توی مپ براش پیدا میکنیم
            if not moved:
                for _ in range(50):
                    nx = random.randint(0, self.world.rows - 1)
                    ny = random.randint(0, self.world.cols - 1)
                    if self.world.is_valid_position(nx, ny) and (nx, ny) not in new_state:
                        new_state[idx] = (nx, ny)
                        break
                        
        elif op == 'add':
            # اضافه کردن سنسور جدید در یک موقعیت خالی و معتبر
            for _ in range(100):
                nx = random.randint(0, self.world.rows - 1)
                ny = random.randint(0, self.world.cols - 1)
                if self.world.is_valid_position(nx, ny) and (nx, ny) not in new_state:
                    new_state.append((nx, ny))
                    break
                    
        elif op == 'remove':
            # حذف تصادفی یکی از سنسورها
            idx = random.randint(0, len(new_state) - 1)
            new_state.pop(idx)
            
        return new_state

    def initialize_state(self):
        # ساخت چیدمان اولیه تصادفی
        state = []
        num_sensors = random.randint(1, self.max_sensors)
        attempts = 0
        
        while len(state) < num_sensors and attempts < 1000:
            nx = random.randint(0, self.world.rows - 1)
            ny = random.randint(0, self.world.cols - 1)
            if self.world.is_valid_position(nx, ny) and (nx, ny) not in state:
                state.append((nx, ny))
            attempts += 1
            
        return state
    
    