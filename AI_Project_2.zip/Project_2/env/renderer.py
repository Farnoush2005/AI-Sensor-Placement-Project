import pygame
from env.config import (
    CELL_SIZE, MARGIN,
    WINDOW_TITLE,
    WHITE, BLACK, RED, BLUE, GRAY
)


INFO_HEIGHT = 60


class Renderer:

    def __init__(self, world):

        pygame.init()

        self.world = world

        self.grid_width  = world.cols * CELL_SIZE
        self.grid_height = world.rows * CELL_SIZE

     
        self.width  = self.grid_width
        self.height = self.grid_height + INFO_HEIGHT

        self.screen = pygame.display.set_mode(
            (self.width, self.height)
        )
        pygame.display.set_caption(WINDOW_TITLE)

       

        font_size = max(14, min(22, self.grid_width // 30))
        self.font = pygame.font.SysFont('Arial', font_size)

    def draw(self,
             state,
             sensor_range,
             iteration,
             cost,
             algorithm_name):

        self.screen.fill(WHITE)

       
        for i in range(self.world.rows):
            for j in range(self.world.cols):

                x = j * CELL_SIZE
                y = i * CELL_SIZE

                rect = pygame.Rect(
                    x, y,
                    CELL_SIZE - MARGIN,
                    CELL_SIZE - MARGIN
                )

                value = self.world.grid[i][j]
                color = WHITE
                if value == 'X':
                    color = GRAY
                elif value == 'T':
                    color = RED

                pygame.draw.rect(self.screen, color, rect)
                pygame.draw.rect(self.screen, BLACK, rect, 1)

       
        for (sx, sy) in state:

         
            for i in range(self.world.rows):
                for j in range(self.world.cols):
                    if abs(sx - i) + abs(sy - j) <= sensor_range:
                        overlay = pygame.Surface(
                            (CELL_SIZE - MARGIN, CELL_SIZE - MARGIN),
                            pygame.SRCALPHA
                        )
                        overlay.fill((50, 100, 255, 60))
                        self.screen.blit(overlay, (j * CELL_SIZE, i * CELL_SIZE))

   
            center_x = sy * CELL_SIZE + CELL_SIZE // 2
            center_y = sx * CELL_SIZE + CELL_SIZE // 2
            pygame.draw.circle(
                self.screen, BLUE,
                (center_x, center_y),
                CELL_SIZE // 4
            )

       
        
        info_rect = pygame.Rect(0, self.grid_height, self.width, INFO_HEIGHT)
        pygame.draw.rect(self.screen, (240, 240, 240), info_rect)
        pygame.draw.line(
            self.screen, (180, 180, 180),
            (0, self.grid_height),
            (self.width, self.grid_height),
            1
        )

        text = (
            f'{algorithm_name}  |  '
            f'Iteration: {iteration}  |  '
            f'Cost: {cost}'
        )

        surface = self.font.render(text, True, BLACK)

        
        text_y = self.grid_height + (INFO_HEIGHT - surface.get_height()) // 2
        self.screen.blit(surface, (10, text_y))

        pygame.display.flip()

    def animate(self,
                states_history,
                evaluations,
                algorithm_name,
                delay=50):

        for iteration, state in enumerate(states_history):

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return

            self.draw(
                state,
                self.world.sensor_range,
                iteration,
                evaluations[iteration],
                algorithm_name
            )

            pygame.time.delay(delay)